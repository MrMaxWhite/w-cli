module.exports = {
  'template-1': {
    url: 'https://github.com/MrMaxWhite/w-cli-template-1',
    downloadUrl: 'https://github.com/MrMaxWhite/w-cli-template-1#master',
    description: '测试模板1'
  },
  'template-2': {
    url: 'https://github.com/MrMaxWhite/w-cli-template-2',
    downloadUrl: 'https://github.com/MrMaxWhite/w-cli-template-2#master',
    description: '测试模板2'
  }
}
